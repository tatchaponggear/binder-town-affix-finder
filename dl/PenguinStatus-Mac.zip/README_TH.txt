🐧 Penguin Status — มาร่วมเป็นขบวนการเพนกวินด้วยกัน!
=====================================================
ตั้งสถานะ Discord ว่า "กำลังเล่น Penguin" พร้อมรูปเพนกวินนักดาบ + ปุ่มลัดไปทุกเมนูของ penguinzgear.com
ใช้ Rich Presence ของแอป Discord บนเครื่อง (แบบเดียวกับเกม) · ไม่ใช้ token / รหัสผ่านบัญชี
ต้องเปิด Discord แบบแอปบนเครื่อง (Discord บนเว็บเบราว์เซอร์ใช้ไม่ได้)
หน้าเว็บ: https://penguinzgear.com/penguin-status

เปิดโปรแกรม
-----------
Windows 10/11:  แตก zip แล้วดับเบิลคลิก PenguinStatus.exe (ไฟล์เดียว ไม่ต้องติดตั้ง)
                ถ้าขึ้น "Windows protected your PC" → More info → Run anyway
macOS 12 ขึ้นไป (Apple Silicon / Intel):
                แตก zip → ลาก "Penguin Status.app" ไปไว้ใน Applications → ดับเบิลคลิก
                ถ้าขึ้นว่าเปิดไม่ได้ / ไม่รู้จักผู้พัฒนา:
                  System Settings → Privacy & Security → เลื่อนลงล่าง → กด "Open Anyway" (ทำครั้งเดียว)

ใช้งาน
------
1. Application ID ใส่ไว้ให้แล้ว กด "▶ เริ่มแสดงสถานะ" ได้เลย
2. แก้ข้อความได้ตามใจ:
   - บรรทัดบน        เช่น Binder Town
   - บรรทัดล่าง      ใส่ได้หลายบรรทัด โปรแกรมหมุนเปลี่ยนให้ทุก X วินาที
   - ปุ่ม 1 / ปุ่ม 2   ลิงก์ที่คนอื่นกดได้จากโปรไฟล์คุณ (ตัวเองกดไม่ได้)
   - แสดงเวลาที่เล่น
3. เปิดโปรแกรมทิ้งไว้ · กด "■ หยุด" หรือปิดหน้าต่าง = สถานะหาย
   (แก้ข้อความระหว่างเปิดอยู่ได้เลย อัปเดตเองภายใน 15 วินาที)
4. 🧭 ทางลัดเมนู Binder Town: กดเปิดหน้าบิลด์ ออฟชั่น Skill Tree เวลาบอส ฯลฯ ในเบราว์เซอร์ได้ทันที

ถ้าไม่ขึ้นใน Discord
--------------------
- Discord → Settings → Activity Privacy → เปิด "Share your detected activities with others"
- ปิดโหมด Invisible
- "หา Discord ไม่เจอ" = ยังไม่ได้เปิดแอป Discord หรือเปิดแบบเว็บ

ความเป็นส่วนตัว: https://penguinzgear.com/penguin-status-privacy
ค่าที่ตั้งไว้บันทึกในเครื่อง  Mac: ~/.penguin-status/config.json  ·  Windows: %APPDATA%\PenguinStatus\config.txt
